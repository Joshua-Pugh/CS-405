#include <iomanip>
#include <iostream>
#include <cstring>  // For std::strlen

/* Test cases:
* Input string with exactly 7 characters: Test123
* Input string with exactly 19 characters: "1234567890123456789"
* Input string with exactly 20 characters: "12345678901234567890"
* Input string with exactly 41 characters: ThisIsAVeryLongInputThatExceedsBufferSize
*/


int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_number
    //  variable, and its position in the declaration. It must always be directly before the variable used for input.
    //  You must notify the user if they entered too much data.

    // The account number must remain unmodified and we do not want buffer overflow to alter it.
    const std::string account_number = "CharlieBrown42";

    // We will use a smaller buffer to safely capture user input.
    char user_input[20]; // Array to hold user input. Limited to 19 chars + 1 for the null terminator.

    std::cout << "Enter a value: ";

    // Read up to 19 characters from input (leaving space for the null terminator)
    std::cin.get(user_input, sizeof(user_input));

    // Check if the input exceeded the buffer size (19 characters), which means a potential overflow attempt.
    // cin.peek() checks the next character in the input stream without removing it. If it isn't the newline character ('\n'), 
    // we know the input exceeded the buffer size, so we trigger the warning and remove excess chars.
    if (std::cin.gcount() == sizeof(user_input) - 1 && std::cin.peek() != '\n') {
        std::cin.clear();  // Clear the error flag in case of overflow
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Ignore remaining input
        std::cout << "Warning: Input too long. Only the first 19 characters were considered.\n";
    }

    // Null-terminate the string explicitly, in case user_input was not fully terminated.
    user_input[sizeof(user_input) - 1] = '\0';

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
