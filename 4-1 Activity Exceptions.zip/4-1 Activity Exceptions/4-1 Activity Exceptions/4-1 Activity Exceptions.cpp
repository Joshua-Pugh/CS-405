// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

// Custom Exception class
class CustomException : public std::exception {
public:

    // Overriding the what() method to return a custom error message
    const char* what() const noexcept override {
        return "Custom exception occurred";  // Custom message for the exception
    }
};

// Function that throws a standard exception (std::runtime_error)
bool do_even_more_custom_application_logic() {

    // Throwing a standard exception (runtime_error)
    throw std::runtime_error("Standard exception thrown in do_even_more_custom_application_logic");

    std::cout << "Running Even More Custom Application Logic." << std::endl;
    return true;
}

// Function that handles custom application logic and exceptions
void do_custom_application_logic() {

    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap the call to do_even_more_custom_application_logic() with an exception handler
    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {  // Catching any standard exception
        std::cout << "Exception caught: " << e.what() << std::endl;
    }

    // Throw a custom exception derived from std::exception
    throw CustomException();  // Throwing a CustomException

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Function that performs division and handles divide by zero errors
float divide(float num, float den) {

    // Throwing an exception for divide by zero errors
    if (den == 0) {
        throw std::invalid_argument("Division by zero");  // Throwing std::invalid_argument
    }

    return num / den;
}

// Function that handles division logic with exception handling
void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    // Creating an exception handler to capture only the exception thrown by divide
    try {
        auto result = divide(numerator, denominator);
        std::cout << "Result: " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {  // Catching invalid_argument (divide by zero)
        std::cout << "Exception caught in do_division: " << e.what() << std::endl;
    }
}

// Main function with exception handlers for custom and standard exceptions
int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    // Exception handlers that catch (in this order):
    // 1. CustomException
    // 2. std::exception
    // 3. uncaught exception (catch-all handler)

    try {
        do_division();  // Call the division function
        do_custom_application_logic();  // Call the custom application logic function
    }
    catch (const CustomException& e) {  // Catching the custom exception
        std::cout << "Custom Exception caught in main: " << e.what() << std::endl;  // Catching CustomException
    }
    catch (const std::exception& e) {  // Catching any other standard exception
        std::cout << "Exception caught in main: " << e.what() << std::endl;
    }
    catch (...) {  // Catching any uncaught exceptions
        std::cout << "Unknown Exception caught in main" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu